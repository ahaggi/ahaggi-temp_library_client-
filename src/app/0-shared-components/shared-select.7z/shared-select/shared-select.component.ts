import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { distinctUntilChanged, map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-shared-select',
  templateUrl: './shared-select.component.html',
  styleUrls: ['./shared-select.component.css']
})
export class SharedSelectComponent implements OnInit {

  @Input()
  listOfAllOptions: SharedSelectOption[];

  @Input()
  // either this solution or get formParent:formGroup and a formController as an input,, remember to remove the formController before parsing it to book! 
  isRequiredFormField?: boolean;

  filteredOptionsObs$;
  selectedOptions: SharedSelectOption[];

  filterController = new FormControl();

  constructor() { }

  ngOnInit(): void {
    this.filteredOptionsObs$ = this.filterController.valueChanges.pipe(
      distinctUntilChanged(),
      startWith(''),
      map((value: string) => this.applyFilter(value))
    );

    this._init()
  }
  // Intercept inputs property changes with ngOnChanges
  // https://angular.io/guide/component-interaction
  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

    // if (changes['listOfAllOptions'].isFirstChange()) { // Due to initialization by angular
    //   doStuff();
    // } else {  // due to business logic 
    //   doMoreStuff();
    // }

    if (changes.hasOwnProperty('listOfAllOptions')) {
      this.listOfAllOptions = changes['listOfAllOptions'].currentValue;
    }
    this._init()
  }


  _init(){
    this.selectedOptions = this.listOfAllOptions.filter(elem => {
      return elem.checked
    })
    this.filterController.setValue('')
  }

  onChange(elem, value) {
    if (value)
      this.addselectedOption(elem)
    else
      this.removeselectedOption(elem)

      // reset the filterInput
    this.filterController.setValue('')
  }

  addselectedOption(elem) {
    elem.checked = true
    this.selectedOptions.push(elem)
  }

  removeselectedOption(elem) {
    elem.checked = false
    let ndx = this.selectedOptions.indexOf(elem)
    if (ndx != -1)
      this.selectedOptions.splice(ndx, 1)

  }

  applyFilter(term: string) {
    const filterValue = term.toLowerCase();
    console.log(filterValue)
    return this.listOfAllOptions.filter(auth => {
      return (auth.viewValue.fst.toLowerCase().includes(filterValue) ||
        auth.viewValue.snd.toLowerCase().includes(filterValue))
    });
  }


  getSelectedOptions(){
    return this.selectedOptions
  }
}


export type SharedSelectOption = {
  value: string;
  viewValue: { fst: string, snd: string };
  checked: boolean;

}